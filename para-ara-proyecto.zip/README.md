# 💜 Para Ara — Proyecto descargable

Página interactiva, romántica y elegante para pedir perdón (o volver a preguntar) con estética Kuromi: negros, morados y detalles suaves.

## 🚀 Cómo verlo localmente

1. Descomprime este archivo.
2. Abre una terminal en la carpeta del proyecto.
3. Instala las dependencias:

```bash
bun install
# o, si prefieres npm:
npm install
```

4. Inicia el servidor de desarrollo:

```bash
bun run dev
# o
npm run dev
```

5. Abre la URL que te aparezca (normalmente `http://localhost:8080`).

## 📝 Cómo personalizar textos, fotos y fecha

Todo el contenido editable está en un solo archivo:

```
src/content/story.ts
```

Allí puedes cambiar:
- **Fecha de acceso** (`fechaClave`)
- **Nombre de tu novia** (`nombre`)
- **Título y subtítulo** de la pantalla de entrada
- **Texto de la carta** (capítulo I)
- **Mensajes románticos** (capítulo II)
- **Fotos de la galería** (capítulo III)
- **Hitos de la línea del tiempo** (capítulo IV)
- **Pregunta final y mensajes** (capítulo V)
- **Música de fondo** (opcional)

Las fotos se encuentran en `src/assets/images/`. Puedes reemplazarlas por las tuyas (conserva los nombres `foto1.jpeg`, `foto2.jpeg`, etc.) y actualizar los textos en `story.ts`.

## 🌐 Cómo publicarlo en internet

Si quieres que Ara lo vea desde su celular, la forma más fácil es publicar el proyecto desde el editor de Lovable con el botón **Publicar**.

También puedes hacer un build de producción:

```bash
bun run build
# o
npm run build
```

## 🎨 Tecnologías

- React 19 + TanStack Start
- Tailwind CSS v4
- TypeScript
- Vite

## 💡 Tip

Si quieres cambiar colores, fuentes o animaciones globales, revisa `src/styles.css`.
