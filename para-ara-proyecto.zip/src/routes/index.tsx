import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { story } from "@/content/story";
import { Petals } from "@/components/Petals";
import { LockScreen } from "@/components/LockScreen";
import { MusicToggle } from "@/components/MusicToggle";
import { LetterChapter } from "@/components/chapters/LetterChapter";
import { FeelingsChapter } from "@/components/chapters/FeelingsChapter";
import { GalleryChapter } from "@/components/chapters/GalleryChapter";
import { TimelineChapter } from "@/components/chapters/TimelineChapter";
import { Finale } from "@/components/chapters/Finale";

const titulo = `Perdóname, ${story.nombre}`;
const descripcion =
  "Una experiencia interactiva por capítulos: cartas, recuerdos, fotos y una pregunta al final.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${titulo} — nuestra historia` },
      { name: "description", content: descripcion },
      { property: "og:title", content: `${titulo} — nuestra historia` },
      { property: "og:description", content: descripcion },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Index,
});

const TOTAL = story.capitulos.length + 1; // capítulos + final

function Index() {
  const [unlocked, setUnlocked] = useState(false);
  const [paso, setPaso] = useState(0);

  const ir = (n: number) => {
    setPaso(Math.min(Math.max(n, 0), TOTAL - 1));
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (!unlocked) {
    return (
      <main className="relative min-h-screen overflow-hidden bg-background">
        <div className="aura" />
        <Petals count={14} />
        <LockScreen onUnlock={() => setUnlocked(true)} />
      </main>
    );
  }

  const [cap1, cap2, cap3, cap4] = story.capitulos;

  return (
    <main className="relative min-h-screen overflow-hidden bg-background">
      <div className="aura" />
      <Petals />
      <MusicToggle />

      <div className="relative z-10 mx-auto w-full max-w-3xl px-5 pb-32 pt-16">
        <h1 className="sr-only">{titulo}</h1>

        <div key={paso} className="animate-chapter-in">
          {paso === 0 && cap1 && <LetterChapter data={cap1 as never} />}
          {paso === 1 && cap2 && <FeelingsChapter data={cap2 as never} />}
          {paso === 2 && cap3 && <GalleryChapter data={cap3 as never} />}
          {paso === 3 && cap4 && <TimelineChapter data={cap4 as never} />}
          {paso === 4 && <Finale onVolverCarta={() => ir(0)} />}
        </div>
      </div>

      {/* Navegación tipo aventura */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border/60 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center gap-4 px-5 py-4">
          <button
            onClick={() => ir(paso - 1)}
            disabled={paso === 0}
            className="nav-arrow"
            aria-label="Capítulo anterior"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <div className="flex min-w-0 flex-1 items-center justify-center gap-2">
            {Array.from({ length: TOTAL }).map((_, i) => (
              <button
                key={i}
                onClick={() => ir(i)}
                aria-label={`Ir al capítulo ${i + 1}`}
                aria-current={i === paso}
                className={`h-2 rounded-full transition-all ${
                  i === paso ? "w-8 bg-primary shadow-glow" : "w-2 bg-border hover:bg-primary/50"
                }`}
              />
            ))}
          </div>

          <button
            onClick={() => ir(paso + 1)}
            disabled={paso === TOTAL - 1}
            className="nav-arrow"
            aria-label="Siguiente capítulo"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </nav>
    </main>
  );
}
