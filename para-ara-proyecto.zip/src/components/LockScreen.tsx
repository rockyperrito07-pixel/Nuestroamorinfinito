import { useState } from "react";
import { story } from "@/content/story";
import { Typewriter } from "./Typewriter";

/** Pantalla de acceso: pide la fecha secreta. */
export function LockScreen({ onUnlock }: { onUnlock: () => void }) {
  const [value, setValue] = useState("");
  const [error, setError] = useState(false);
  const [opening, setOpening] = useState(false);

  const format = (raw: string) => {
    const d = raw.replace(/\D/g, "").slice(0, 8);
    const parts = [d.slice(0, 2), d.slice(2, 4), d.slice(4, 8)].filter(Boolean);
    return parts.join("/");
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value === story.fechaClave) {
      setError(false);
      setOpening(true);
      setTimeout(onUnlock, 1100);
    } else {
      setError(true);
    }
  };

  return (
    <div
      className={`relative z-10 flex min-h-screen items-center justify-center px-5 py-16 transition-all duration-700 ${
        opening ? "scale-110 opacity-0 blur-sm" : "opacity-100"
      }`}
    >
      <div className="w-full max-w-md text-center">
        <div className="mx-auto mb-8 h-20 w-20 animate-float rounded-full border border-primary/40 bg-gradient-to-br from-primary/30 to-transparent shadow-glow" />

        <p className="text-xs uppercase tracking-[0.45em] text-primary/80">
          {story.acceso.titulo}
        </p>
        <h1 className="mt-4 font-display text-4xl leading-tight text-foreground sm:text-5xl">
          Hola, {story.nombre}
        </h1>
        <Typewriter
          text={story.acceso.subtitulo}
          className="mx-auto mt-4 min-h-12 max-w-sm text-sm text-muted-foreground"
        />

        <form onSubmit={submit} className="mt-8 space-y-4">
          <input
            inputMode="numeric"
            autoComplete="off"
            value={value}
            onChange={(e) => {
              setValue(format(e.target.value));
              setError(false);
            }}
            placeholder={story.acceso.pista}
            aria-label={story.acceso.subtitulo}
            className={`w-full rounded-2xl border bg-card/60 px-5 py-4 text-center font-display text-2xl tracking-[0.2em] text-foreground outline-none backdrop-blur transition-all placeholder:text-muted-foreground/50 focus:border-primary focus:shadow-glow ${
              error ? "animate-shake border-destructive" : "border-border"
            }`}
          />
          <p
            className={`min-h-5 text-xs text-destructive transition-opacity ${
              error ? "opacity-100" : "opacity-0"
            }`}
          >
            {story.acceso.error}
          </p>
          <button type="submit" className="btn-romance w-full">
            {story.acceso.boton}
          </button>
        </form>
      </div>
    </div>
  );
}
