import { useState } from "react";
import { Heart } from "lucide-react";
import { Reveal } from "../Reveal";
import { Hearts } from "../Hearts";
import { Typewriter } from "../Typewriter";
import { story } from "@/content/story";

type Respuesta = "pendiente" | "si" | "no";

/** Capítulo final: la pregunta. */
export function Finale({ onVolverCarta }: { onVolverCarta: () => void }) {
  const [respuesta, setRespuesta] = useState<Respuesta>("pendiente");
  const [noPos, setNoPos] = useState({ x: 0, y: 0 });
  const [intentosNo, setIntentosNo] = useState(0);
  const f = story.final;

  const esquivar = () => {
    setNoPos({ x: (Math.random() * 2 - 1) * 90, y: (Math.random() * 2 - 1) * 40 });
  };

  const manejarNo = () => {
    if (intentosNo < 3) {
      esquivar();
      setIntentosNo((n) => n + 1);
    } else {
      setRespuesta("no");
    }
  };

  const volverAPregunta = () => {
    setRespuesta("pendiente");
    setIntentosNo(0);
    setNoPos({ x: 0, y: 0 });
  };

  return (
    <section className="chapter text-center">
      {respuesta === "si" && <Hearts confetti />}

      {respuesta === "pendiente" && (
        <>
          <Reveal variant="scale">
            <div className="mx-auto mb-8 flex h-24 w-24 animate-heartbeat items-center justify-center rounded-full bg-gradient-primary shadow-glow">
              <Heart className="h-10 w-10 fill-current text-primary-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">{f.intro}</p>
          </Reveal>
          <Reveal delay={200}>
            <h2 className="mt-6 font-display text-3xl leading-tight text-foreground sm:text-5xl">
              {f.pregunta}
            </h2>
          </Reveal>
          <Reveal delay={400}>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <button onClick={() => setRespuesta("si")} className="btn-romance">
                {f.si}
              </button>
              <button
                onClick={manejarNo}
                onMouseEnter={manejarNo}
                style={{ transform: `translate(${noPos.x}px, ${noPos.y}px)` }}
                className="btn-ghost-romance transition-transform duration-300"
              >
                {f.no}
              </button>
            </div>
          </Reveal>
        </>
      )}

      {respuesta === "si" && (
        <div className="animate-scale-in">
          <h2 className="font-display text-4xl text-foreground sm:text-5xl">{f.graciasTitulo}</h2>
          <Typewriter
            text={f.graciasTexto}
            speed={28}
            className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted-foreground"
          />
          <p className="mt-10 text-4xl">💜</p>
        </div>
      )}

      {respuesta === "no" && (
        <div className="animate-fade-in">
          <h2 className="font-display text-3xl text-foreground sm:text-4xl">{f.noTitulo}</h2>
          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted-foreground">
            {f.noTexto}
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <button onClick={onVolverCarta} className="btn-ghost-romance">
              {f.noBoton}
            </button>
            <button onClick={volverAPregunta} className="btn-romance">
              Volver a la pregunta
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
