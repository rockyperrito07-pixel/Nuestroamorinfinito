import { Reveal } from "../Reveal";

type Data = {
  indice: string;
  titulo: string;
  subtitulo: string;
  hitos: { fecha: string; texto: string }[];
};

/** Capítulo IV: línea del tiempo de recuerdos. */
export function TimelineChapter({ data }: { data: Data }) {
  return (
    <section className="chapter">
      <Reveal>
        <p className="chapter-index">{data.indice}</p>
        <h2 className="chapter-title">{data.titulo}</h2>
        <p className="mt-3 text-sm text-muted-foreground">{data.subtitulo}</p>
      </Reveal>

      <ol className="timeline mt-12">
        {data.hitos.map((hito, i) => (
          <li key={hito.fecha}>
            <Reveal delay={i * 120} variant="left">
              <span className="timeline-dot" />
              <p className="text-xs uppercase tracking-[0.3em] text-primary/90">{hito.fecha}</p>
              <p className="mt-2 font-display text-lg text-foreground/90 sm:text-xl">
                {hito.texto}
              </p>
            </Reveal>
          </li>
        ))}
      </ol>
    </section>
  );
}
