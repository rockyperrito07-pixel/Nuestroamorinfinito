import { Reveal } from "../Reveal";

type Data = { indice: string; titulo: string; lineas: string[] };

/** Capítulo II: frases que aparecen entre pétalos. */
export function FeelingsChapter({ data }: { data: Data }) {
  return (
    <section className="chapter text-center">
      <Reveal>
        <p className="chapter-index">{data.indice}</p>
        <h2 className="chapter-title">{data.titulo}</h2>
      </Reveal>

      <div className="mt-12 space-y-8">
        {data.lineas.map((linea, i) => (
          <Reveal key={linea} delay={i * 180} variant={i % 2 ? "right" : "left"}>
            <p className="glass-line font-display text-xl leading-relaxed text-foreground/90 sm:text-2xl">
              {linea}
            </p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
