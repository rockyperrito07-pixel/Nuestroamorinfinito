import { useState } from "react";
import { Typewriter } from "../Typewriter";
import { Reveal } from "../Reveal";

type Data = {
  indice: string;
  titulo: string;
  texto: string[];
  firma: string;
};

/** Capítulo I: un sobre que se abre y una carta escrita a máquina. */
export function LetterChapter({ data }: { data: Data }) {
  const [open, setOpen] = useState(false);
  const [line, setLine] = useState(0);

  return (
    <section className="chapter">
      <Reveal>
        <p className="chapter-index">{data.indice}</p>
        <h2 className="chapter-title">{data.titulo}</h2>
      </Reveal>

      {!open ? (
        <Reveal variant="scale" className="mt-12">
          <button
            onClick={() => setOpen(true)}
            className="group relative mx-auto block w-full max-w-sm"
            aria-label="Abrir la carta"
          >
            <div className="envelope">
              <div className="envelope-flap" />
              <div className="envelope-body">
                <span className="font-display text-2xl text-primary-foreground/90">
                  Para ti ♥
                </span>
              </div>
            </div>
            <span className="mt-6 block text-xs uppercase tracking-[0.35em] text-muted-foreground group-hover:text-primary">
              Toca para abrir
            </span>
          </button>
        </Reveal>
      ) : (
        <div className="letter-paper mt-12 animate-letter">
          {data.texto.map((t, i) =>
            i <= line ? (
              <Typewriter
                key={i}
                text={t}
                speed={26}
                className="mb-5 font-display text-lg leading-relaxed text-foreground/90 sm:text-xl"
                onDone={() => setLine((l) => Math.max(l, i + 1))}
              />
            ) : null,
          )}
          {line >= data.texto.length && (
            <p className="mt-8 text-right text-sm italic text-primary/90 animate-fade-in">
              {data.firma}
            </p>
          )}
        </div>
      )}
    </section>
  );
}
