import { useState } from "react";
import { X } from "lucide-react";
import { Reveal } from "../Reveal";

type Foto = { src: string; alt: string; pie: string };
type Data = { indice: string; titulo: string; subtitulo: string; fotos: Foto[] };

/** Capítulo III: galería moderna con lightbox. */
export function GalleryChapter({ data }: { data: Data }) {
  const [activa, setActiva] = useState<Foto | null>(null);

  return (
    <section className="chapter">
      <Reveal>
        <p className="chapter-index">{data.indice}</p>
        <h2 className="chapter-title">{data.titulo}</h2>
        <p className="mt-3 text-sm text-muted-foreground">{data.subtitulo}</p>
      </Reveal>

      <div className="mt-12 columns-2 gap-4 sm:columns-3 [&>*]:mb-4">
        {data.fotos.map((foto, i) => (
          <Reveal key={foto.src} delay={i * 90} variant="scale">
            <button
              onClick={() => setActiva(foto)}
              className="photo-card group block w-full"
              aria-label={`Ver foto: ${foto.pie}`}
            >
              <img
                src={foto.src}
                alt={foto.alt}
                loading="lazy"
                className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <span className="photo-caption">{foto.pie}</span>
            </button>
          </Reveal>
        ))}
      </div>

      {activa && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 p-5 backdrop-blur-md animate-fade-in"
          onClick={() => setActiva(null)}
          role="dialog"
          aria-modal="true"
        >
          <button
            className="absolute right-5 top-5 rounded-full border border-border p-2 text-muted-foreground hover:text-foreground"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
          <figure className="max-h-[85vh] max-w-3xl animate-scale-in text-center">
            <img
              src={activa.src}
              alt={activa.alt}
              className="max-h-[75vh] rounded-3xl border border-border object-contain shadow-glow"
            />
            <figcaption className="mt-4 font-display text-lg text-foreground/90">
              {activa.pie}
            </figcaption>
          </figure>
        </div>
      )}
    </section>
  );
}
