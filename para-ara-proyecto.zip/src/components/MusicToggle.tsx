import { useEffect, useRef, useState } from "react";
import { Music, Pause } from "lucide-react";
import { story } from "@/content/story";

/** Música opcional, siempre bajo control de quien lee. */
export function MusicToggle() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    const audio = new Audio(story.musica.url);
    audio.loop = true;
    audio.volume = 0.35;
    audioRef.current = audio;
    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, []);

  const toggle = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
    } else {
      void audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
  };

  return (
    <button
      onClick={toggle}
      aria-label={playing ? "Pausar música" : "Reproducir música"}
      className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full border border-border bg-card/80 px-4 py-3 text-xs text-muted-foreground backdrop-blur transition-colors hover:border-primary hover:text-foreground"
    >
      {playing ? <Pause className="h-4 w-4" /> : <Music className="h-4 w-4" />}
      <span className="hidden sm:inline">{story.musica.etiqueta}</span>
    </button>
  );
}
