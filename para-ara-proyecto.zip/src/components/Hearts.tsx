import { useMemo } from "react";

/** Lluvia de corazones + confeti para el final feliz. */
export function Hearts({ confetti = false }: { confetti?: boolean }) {
  const items = useMemo(
    () =>
      Array.from({ length: confetti ? 60 : 24 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 4,
        duration: 4 + Math.random() * 5,
        size: 10 + Math.random() * 18,
        heart: !confetti || i % 2 === 0,
        hue: [280, 320, 260, 200][i % 4],
      })),
    [confetti],
  );

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-30 overflow-hidden">
      {items.map((it) => (
        <span
          key={it.id}
          className="confetti-bit"
          style={{
            left: `${it.left}%`,
            animationDelay: `${it.delay}s`,
            animationDuration: `${it.duration}s`,
            fontSize: it.size,
            color: `oklch(0.7 0.18 ${it.hue})`,
          }}
        >
          {it.heart ? "♥" : "✦"}
        </span>
      ))}
    </div>
  );
}
