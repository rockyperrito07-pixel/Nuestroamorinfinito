import foto1 from "@/assets/images/foto1.jpeg";
import foto2 from "@/assets/images/foto2.jpeg";
import foto3 from "@/assets/images/foto3.jpeg";
import foto4 from "@/assets/images/foto4.jpeg";
import foto5 from "@/assets/images/foto5.jpeg";
import foto6 from "@/assets/images/foto6.jpeg";
import foto7 from "@/assets/images/foto7.jpeg";

/**
 * TODO PERSONALIZABLE: cambia aquí los textos, las fechas y las fotos.
 * Para cambiar una foto, reemplaza el archivo en `src/assets/images/`.
 */

export const story = {
  nombre: "Ara",
  // Fecha que se pide en la pantalla de acceso (formato DD/MM/AAAA)
  fechaClave: "13/10/2009",
  acceso: {
    titulo: "Solo para Ara",
    subtitulo: "Escribe la fecha que nunca voy a olvidar",
    pista: "DD / MM / AAAA",
    error: "Esa no es… pero sigue intentando, mi amor.",
    boton: "Abrir nuestra historia",
  },

  capitulos: [
    {
      id: "carta",
      indice: "Capítulo I",
      titulo: "La carta que no supe decirte",
      texto: [
        "Ara, Te amo. No quiero justificarme por mis errores, quiero entenderte.",
        "Escribí esto pensando en tu risa, en cómo se te arruga la nariz cuando algo te da ternura, y en lo mucho que odio ser el motivo de tu silencio.",
        "Perdóname por herirte. Prometo escucharte más y hablar mejor.",
      ],
      firma: "Con todo lo que soy, tuyo.",
    },
    {
      id: "petalos",
      indice: "Capítulo II",
      titulo: "Lo que siento cuando pienso en ti",
      lineas: [
        "Contigo hasta lo simple se vuelve bonito.",
        "Eres mi lugar favorito y mi mejor costumbre.",
        "Si el amor fuera un idioma, yo solo hablaría de ti.",
      ],
    },
    {
      id: "galeria",
      indice: "Capítulo III",
      titulo: "Nuestros momentos",
      subtitulo: "Cada foto, una razón más para no perderte.",
      fotos: [
        { src: foto7, alt: "Nosotros", pie: "Tus ojos, mi debilidad." },
        { src: foto6, alt: "Nosotros", pie: "Videollamadas hasta tarde." },
        { src: foto5, alt: "Nosotros", pie: "Tu calma me calma." },
        { src: foto4, alt: "Nosotros", pie: "Cerca, siempre cerca." },
        { src: foto3, alt: "Nosotros", pie: "Bonita sin intentarlo." },
        { src: foto2, alt: "Nosotros", pie: "Mi persona favorita." },
        { src: foto1, alt: "Nosotros", pie: "Y este espejo que te ama." },
      ],
    },
    {
      id: "tiempo",
      indice: "Capítulo IV",
      titulo: "Línea del tiempo",
      subtitulo: "Recuerdos que no se borran con una pelea.",
      hitos: [
        { fecha: "El primer hola", texto: "Nunca imaginé que una conversación cambiaría todo." },
        { fecha: "LA PRIMERA VIDEOLLAMADA", texto: "Me temblaban las manos y tú lo notaste." },
        { fecha: "El primer 'te amo'", texto: "Cuando me lo dijiste casi me desmayo" },
        { fecha: "Nuestra primera pelea", texto: "Aprendimos que quedarse también es amor." },
        { fecha: "Hoy", texto: "Aquí estoy, pidiéndote perdón y otra oportunidad." },
      ],
    },
  ],

  final: {
    intro: "Antes de irte de esta página, quiero preguntarte algo.",
    pregunta: "¿Quieres seguir siendo mi novia?",
    si: "Sí, mi amor",
    no: "No",
    graciasTitulo: "Gracias por quedarte",
    graciasTexto:
      "Prometo cuidarte mejor, escucharte más y demostrarte cada día que elegirte no fue casualidad. Te amo, Ara.",
    noTitulo: "Respeto lo que sientes",
    noTexto:
      "No quiero presionarte. Tu tranquilidad vale más que mi orgullo. Si algún día quieres volver a leer mi carta, aquí va a estar esperándote.",
    noBoton: "Volver a leer la carta",
  },

  // Música opcional: cambia esta URL por tu canción favorita (mp3)
  musica: {
    url: "https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=lofi-study-112191.mp3",
    etiqueta: "Nuestra canción",
  },
};

export type Story = typeof story;
